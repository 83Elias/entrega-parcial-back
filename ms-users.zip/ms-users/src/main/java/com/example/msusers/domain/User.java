package com.example.msusers.domain;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;


public class User {
    //esta entidad la modelan ustedes de acuerdo a los atributos que vayan a necesitar
}
