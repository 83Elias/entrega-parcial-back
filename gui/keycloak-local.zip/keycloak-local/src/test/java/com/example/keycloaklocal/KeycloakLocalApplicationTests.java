package com.example.keycloaklocal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KeycloakLocalApplicationTests {

	@Test
	void contextLoads() {
	}

}
