package com.example.keycloaklocal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KeycloakLocalApplication {

	public static void main(String[] args) {
		SpringApplication.run(KeycloakLocalApplication.class, args);
	}

}
